import ufoProcessor
ufoProcessor.build("/Users/aamacbook/Work Interim/Krspy-VF/sources/designspaces/SOURCE PARAMETRIC MASTERS/CRISPY-PARAMETRIC AXES.designspace")
print("Instance builds confirmed!")